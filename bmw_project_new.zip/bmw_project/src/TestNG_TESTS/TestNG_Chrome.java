package TestNG_TESTS;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BASE_CLASS.Utilities;
import EXCEL_UTILITIES.Excel;
import POM_PAGES.Page_1;
import POM_PAGES.page_2;
import POM_PAGES.page_3;

public class TestNG_Chrome {
	
	WebDriver dr;
	Utilities util; //creating object for Utilities calss
	
	Excel obj; //creating object for Excel class
	
	Page_1 p1; // creating object for page_1 class 
	
	page_2 p2; //creating object for page_2 class
	
	page_3 p3; //creating object for page_3 class
	
	String url ="https://www.bmw.in/en/"; //storing url as a srting
	
	@BeforeClass
	public void browser_type()
	{
		util = new Utilities();
		dr = util.launch_browser("chrome", url); //calling method to launch the browser
	}
	
  @Test
  public void f1() 
  {
	  p1=new Page_1(dr);
	  p1.models();     //caling models method
	  
	  p2=new page_2(dr);
	  p2.sel_7(); //calling sel_7 method
	  
	  p3=new page_3(dr);
	  p3.Technical_data();  //calling technical data method
	  
	  String ex="Does not meet my requirement";  //storing error message in string variable to pass to ecxel write mwthod
	  
	  int num=p3.speed();//calling speed mathod
	 
	  if(num<500) //if the condition id true then write the error message to excel
	  {
		  obj=new Excel();
		 obj.write_excel(ex,4,3); //calling excel write method
	  }
	  else
	  {
		  System.out.println("value is greater than 500"); //if the condition is false then printing this message in console
	  }
	  

	  
  }
  @AfterClass
  public void AC()
  {
	 dr.close();  //close the browser
  }
}