package BASE_CLASS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
	
	WebDriver dr;
	public Utilities()
	{
		this.dr = dr;
	}
	
	//mthod to Launch the browser
	public WebDriver launch_browser(String browser, String url)
	{
		if(browser.contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "T_DRIVERS\\chromedriver.exe");
			dr = new ChromeDriver();
		}
		else if(browser.contains("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "T_DRIVERS\\geckodriver.exe");
			dr = new FirefoxDriver();
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	


}

