package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class page_2 {
	
	
	WebDriver dr;
	
	public page_2(WebDriver dr)
	{
		this.dr = dr;
	}
	
	
	By m_7=By.xpath("//div[@style='animation-delay: 150ms;']/a");
	
	By car=By.xpath("//div[@class='enhanced-model-card tw-relative tw-p-300 tw-mb-200 tw-mt-200 tw-relative tw-bg-white hover-out enhanced-model-card-small']/div[1]");
	By car_u=By.xpath("//a[@href='https://www.bmw.in/en/all-models/7-series/sedan/2019/bmw-7-series-sedan-inspire.html']");

	//method to click on number 7
	public void set_m_7()
	{
		dr.findElement(m_7).click();
	}
	
	//method to click on model 7 series car image
	public void set_car()
	{
		WebElement we=dr.findElement(car);
	Actions a=new Actions(dr);
	a.moveToElement(we).build().perform();
	dr.findElement(car_u).click();
	
	}
	
	//fiinal method to call all the method in this page
	public void sel_7() 
	{
		this.set_m_7();
		this.set_car();
	}

}
