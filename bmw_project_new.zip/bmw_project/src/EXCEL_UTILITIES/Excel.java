package EXCEL_UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
	
	//method to write excel
	public void write_excel(String input,int r,int c)
	{
		String FN="T_DATA\\pooja_bmw.xlsx";
		String SN="Sheet1";
		File f= new File(FN);
		
		try {
			
			FileInputStream fis=new FileInputStream(f);
			
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(SN);
			XSSFRow row=sh.getRow(r);
			//XSSFCell cell1=row.createCell(c);
        	XSSFCell cell1=row.getCell(c);
			 //cell1=row.getCell(c);
			cell1.setCellValue(input);
			FileOutputStream fos =new FileOutputStream(f);
			wb.write(fos);
			
		
		} catch (FileNotFoundException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
