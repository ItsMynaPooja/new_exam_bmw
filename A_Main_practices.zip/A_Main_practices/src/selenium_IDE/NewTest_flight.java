package selenium_IDE;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest_flight {
	WebDriver dr;
	main_class obj;
	String url="https://www.selenium.dev/";
	
	
	@BeforeClass
	public void BM()
	{
		obj=new main_class(dr);
		dr=obj.launch_browser("chrome", url);
	}
	
  @Test
  public void f()
  {
	  obj.methods();
	  System.out.println("pass");
	  
	  
	  boolean b = false;
	  try
	  {
		  File f=new File("C:\\Users\\BLTuser.BLT0203\\Downloads\\IEDriverServer_x64_3.150.1.zip");
		  b=true;
	  }catch(Exception e)
	  {
		  b = false; 
	  }
		 SoftAssert sa=new SoftAssert();
		 sa.assertTrue(b);
		 sa.assertAll();

	  
	  
//	  File f=new File("C:\\Users\\BLTuser.BLT0203\\Downloads\\IEDriverServer_x64_3.150.1.zip");
//	  boolean b=f.exists();
//	  	SoftAssert sa=new SoftAssert();
//		 sa.assertTrue(b);
//		 sa.assertAll();
		 
  }
}
