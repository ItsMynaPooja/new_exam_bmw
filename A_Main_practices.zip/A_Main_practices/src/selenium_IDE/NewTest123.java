package selenium_IDE;

import java.io.File;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest123 {
  @Test
  public void f() {
	  
	  File f=new File("C:\\Users\\BLTuser.BLT0203\\Downloads\\IEDriverServer_x64_3.150.1.zip");
	  boolean b=f.exists();
	  	SoftAssert sa=new SoftAssert();
		 sa.assertTrue(b);
		 sa.assertAll();
  }
}
