package Royalcal;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest_royal {
	WebDriver dr;
	main_class obj;
	String url="https://www.royalcaribbean.com/alaska-cruises";
	
	
	@BeforeClass
	public void BM()
	{
		obj=new main_class(dr);
		dr=obj.launch_browser("chrome", url);
	}
	
  @Test
  public void f()
  {
	 String act_name= obj.mathod_1();
System.out.println(act_name);
	 
	 SoftAssert sa=new SoftAssert();
	 sa.assertTrue(act_name.contains("Royal"));
	 // System.out.println("pass");
  }
}
