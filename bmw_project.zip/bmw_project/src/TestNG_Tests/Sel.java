package TestNG_Tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base_class.Utilities;
import POM_Pages.Page_1;
import POM_Pages.page_2;
import POM_Pages.page_3;

public class Sel {
	
	WebDriver dr;
	Utilities util;
	Page_1 p1;
	page_2 p2;
	page_3 p3;
	
	String URL = "https://www.bmw.in/en/";
	@BeforeClass
	public void browser_type()
	{
		util = new Utilities();
		dr = util.launch_browser("CHROME", URL);
	}
	
  @Test
  public void f1() 
  {
	  p1=new Page_1(dr);
	  p1.models();
	  p2=new page_2(dr);
	  p2.sec_page();
	  p3=new page_3(dr);
	  p3.td();
	  
	  String ex=p3.hp();
	 util.wexcel(ex,2,1);
	  int num=p3.n_hp();
	  int n2=p3.speed();
	  boolean b;
	  if((num<500)&&(n2<500))
	  {
		  b=false;
	  }
	  else
		  b=true;
	  Assert.assertTrue(b,"Does not meet my requirement");
  }

}
