package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page_1 {
	
	WebDriver dr;
	public Page_1(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public void models()
	{
		dr.findElement(By.xpath("//div[@class='tw-cursor-pointer'][1]")).click();
	}
	
	
	

}
