package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class page_2 {
	
	
	WebDriver dr;
	
	public page_2(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public void num()
	{
		try {
			Thread.sleep(30);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		dr.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[1]/div/nav/div/div/div[4]/a")).click();
		
	}
	
	public void car()
	{
		dr.findElement(By.xpath("//div[@class='lg:tw-w-1/4 sm:tw-w-1/2 tw-w-full tw-relative']")).click();
	}
	
	public void sec_page()
	{
		this.num();
		this.car();
	}

}
