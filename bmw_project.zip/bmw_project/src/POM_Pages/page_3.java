package POM_Pages;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class page_3 
{
	String hpr;
	String  new_hp;

	WebDriver dr;
	public page_3(WebDriver dr)
	{
		this.dr = dr;
	}
	
	public void td()
	{
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//div[@class='scroll-navigation-content tw-h-full']//div[3]//a")).click();
	}
	
	
	public String hp()
	{
		 hpr=dr.findElement(By.xpath("//*[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div")).getText();
	System.out.println(hpr);
	new_hp=hpr.substring(5,8);
	System.out.println(new_hp);
	return new_hp;
	}
	

	
	public int n_hp()
	{
	int no=Integer.parseInt(new_hp);
	System.out.println(no);
	return no;
	}
	
	public int speed()
	{
		String speed=dr.findElement(By.xpath("//*[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[2]/div/table/tbody/tr[1]/td[2]/div")).getText();
		int n_speed=Integer.parseInt(speed);
		System.out.println(n_speed);
		return n_speed;
		
	}
}
