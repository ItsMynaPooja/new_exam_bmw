package Base_class;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
	
	WebDriver dr;
	public Utilities()
	{
		this.dr = dr;
	}
	
	public WebDriver launch_browser(String browser, String URL)
	{
		if(browser.contains("CHROME"))
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			dr = new ChromeDriver();
		}
		else if(browser.contains("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr = new FirefoxDriver();
		}
		dr.get(URL);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	
	
	public void wexcel(String input,int r,int c)
	{
		String FN="C:\\Users\\BLTuser.BLT235\\Desktop\\Excel\\pooja_bmw.xlsx";
		String SN="Sheet1";
		File f= new File(FN);
		
		try {
			
			FileInputStream fis=new FileInputStream(f);
			
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(SN);
			XSSFRow row=sh.getRow(r);
			//XSSFCell cell1=row.createCell(c);
        	XSSFCell cell1=row.getCell(c);
			 //cell1=row.getCell(c);
			cell1.setCellValue(input);
			FileOutputStream fos =new FileOutputStream(f);
			wb.write(fos);
			
		
		} catch (FileNotFoundException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

