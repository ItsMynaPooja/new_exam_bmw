package POM_PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASS.Wait;

public class Page_1 {
	
	WebDriver dr;
	Wait wt;
	public Page_1(WebDriver dr)
	{
		this.dr = dr;
		wt = new Wait(dr);
	}
	
	By dwn =By.xpath("//a[@class='nav-item'][1]");
	//To click on Downloads
	public void downloads()
	{		
		WebElement wt_dwn=wt.elementToBeClickable(dwn, 20);
		wt_dwn.click();
		
		System.out.println("Clicked on downloads option in 1st page");
	}


}
