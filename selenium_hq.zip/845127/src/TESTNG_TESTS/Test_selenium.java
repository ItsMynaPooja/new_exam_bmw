package TESTNG_TESTS;


import java.io.File;


import org.openqa.selenium.WebDriver;

import org.testng.Assert;

import org.testng.annotations.AfterClass;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;


import BASE_CLASS.Browsers;

import POM_PAGES.Page_1;

import POM_PAGES.Page_2;


public class Test_selenium
 {
	
	
WebDriver dr;

	Browsers Br;
	
Page_1 P1;
	Page_2 P2;
	
	
String URL = "https://www.selenium.dev/";
	
//To launch browser & navigate to selenium.dev site
	
@BeforeClass
	
public void launcher()

	{
		
Br = new Browsers(dr);
		
dr = Br.Launch("Chrome", URL);

	}
	
	
//To pass page 1
    
@Test(priority=1)

    public void page1()
 
    {

	 Page_1 P1 = new Page_1(dr);

	 P1.downloads();
    
}

  
     //To pass page 2
    
 @Test(priority=2)

	 public void page2()

	 {
		 
Page_2 P2 = new Page_2(dr);

		
 P2.download_zip();	

		 
		 //Wait for downloading
	
	 try {
	
			
Thread.sleep(20000);
		
	}
 catch (InterruptedException e) 
{
			

	// TODO Auto-generated catch block
				
e.printStackTrace();
			
}
	
 }
	 
	
 //To assert download
	
 @Test(priority=3)
	
 public void check_download()
	
 {
		
 //Change the Download Path to the local drive!!!!!
		 

	 String downloadPath = "C:\\Users\\BLTuser.BLT0203\\Downloads";
	
	 
	 //To check existence of downloaded file 

	 File file = new File(downloadPath+"\\IEDriverServer_x64_3.150.1.zip");
	
 boolean check = file.exists();
	 
Assert.assertTrue(check, " Not Downloaded!");
	
 }
	 
	
 //To close browser
	
 @AfterClass
	
 public void close_browser()

	 {
		
 dr.close();
	

 }
}

